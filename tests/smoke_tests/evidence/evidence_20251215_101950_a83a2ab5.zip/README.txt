Beta Evidence Package
=====================
Run ID: 20251215_101950_a83a2ab5
Generated: 2025-12-15T10:19:58.109237
Sector: multifamily
Firm: none
Mode: byop

Revit: 2026
Document: Document with 370 sheets

Contents:
- run/: Core run data (report, environment, resolved pack)
- artifacts/: Generated exports with manifest
- diagnostics/: Warnings and debug info

DLL SHA256: not_found
