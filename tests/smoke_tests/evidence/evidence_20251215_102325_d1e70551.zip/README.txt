Beta Evidence Package
=====================
Run ID: 20251215_102325_d1e70551
Generated: 2025-12-15T10:23:34.656292
Sector: multifamily
Firm: none
Mode: byop

Revit: 2026
Document: Document with 370 sheets

Contents:
- run/: Core run data (report, environment, resolved pack)
- artifacts/: Generated exports with manifest
- diagnostics/: Warnings and debug info

DLL SHA256: not_found
