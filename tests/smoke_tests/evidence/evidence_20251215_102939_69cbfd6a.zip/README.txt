======================================================================
SPINE BETA RUN - EVIDENCE PACKAGE
======================================================================
Run ID: 20251215_102939_69cbfd6a
Generated: 2025-12-15T10:29:48.524154

----------------------------------------------------------------------
1. WHAT WAS ATTEMPTED
----------------------------------------------------------------------
  Sector:         multifamily
  Firm Override:  none
  Mode:           byop
  Revit Version:  2026
  Document:       Document with 13 sheets

----------------------------------------------------------------------
2. READINESS ASSESSMENT
----------------------------------------------------------------------
  Grade:          ✓ GREEN
  Score:          100.0%

----------------------------------------------------------------------
3. WHAT CHANGED
----------------------------------------------------------------------
  Iterations:     0
  Tasks Executed: 0
  Tasks Succeeded:0
  Tasks Skipped:  0
  Created:        (none)

----------------------------------------------------------------------
4. FINAL SCORES
----------------------------------------------------------------------
  Pack Coverage:  66.7%
  Quality Score:  100.0%
  Confidence:     87.5%
  Permit Ready:   No

  Stop Reason:    Gate denied by user

----------------------------------------------------------------------
5. HUMAN ACTION REQUIRED
----------------------------------------------------------------------
  (None - all tasks automated)

----------------------------------------------------------------------
6. KNOWN REVIT 2026 CONSTRAINTS
----------------------------------------------------------------------
  The following operations are NOT automated due to Revit 2026 API limits:

  • Legend placement on sheets
      → Workaround: Manual placement required

  • Schedule placement on sheets
      → Workaround: Schedules created, manual placement required

  • Cloud family loading
      → Workaround: Use local .rfa files via loadFamily

  • Titleblock detection
      → Workaround: Inferred from existing sheets

----------------------------------------------------------------------
7. PACKAGE CONTENTS
----------------------------------------------------------------------
  run/
    autopilot_report.json  - Full execution log
    environment.json       - Machine/Revit info
    readiness.json         - Preflight checks
    resolved_pack.json     - Pack configuration
    versions.json          - Version provenance
    command.txt            - Exact CLI command
  artifacts/
    exports/               - Generated exports
    exports_manifest.json  - Export file hashes
  diagnostics/
    warnings.json          - Issues found

======================================================================
DLL SHA256: not_found
======================================================================